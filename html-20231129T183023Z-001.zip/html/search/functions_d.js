var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html#a2f30d5e4bb0a5ca4cebbb2e4200bbc43',1,'Usuario']]]
];
