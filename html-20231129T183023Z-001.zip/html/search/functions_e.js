var searchData=
[
  ['verifica_5fcategoria_0',['verifica_categoria',['../projeto__final_8txt.html#a50dee9dceb529a543705118737a987f0',1,'projeto_final.txt']]],
  ['verificarcpf_1',['VerificarCpf',['../class_sistema.html#a103a42dc7e868f7096986d2b432652cd',1,'Sistema']]],
  ['verificarnome_2',['VerificarNome',['../class_sistema.html#ae9911431bf2d901ffe6a5c071fe8d9d2',1,'Sistema']]],
  ['verificatitulo_3',['VerificaTitulo',['../class_sistema.html#aef9f3f9294e93493fb0a525865ce8e93',1,'Sistema']]]
];
