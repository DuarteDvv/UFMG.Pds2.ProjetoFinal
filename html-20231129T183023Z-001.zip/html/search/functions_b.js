var searchData=
[
  ['savedata_0',['SaveData',['../class_sistema.html#aaf1c9b1139b9519bceaa8a16afa6311a',1,'Sistema']]],
  ['sugerirfilme_1',['SugerirFilme',['../class_sistema.html#a834e54e412fd43af406f1372ce993189',1,'Sistema']]]
];
