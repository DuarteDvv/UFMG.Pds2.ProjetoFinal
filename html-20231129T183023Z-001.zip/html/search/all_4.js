var searchData=
[
  ['existefilme_0',['ExisteFilme',['../class_sistema.html#a8102edc59a6671b26efcecae89c44993',1,'Sistema']]],
  ['existeusuario_1',['ExisteUsuario',['../class_sistema.html#a8c2354bea3738a93cb1c97af9ebd08bd',1,'Sistema']]]
];
